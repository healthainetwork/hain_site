--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Debian 10.5-2.pgdg90+1)
-- Dumped by pg_dump version 10.5 (Debian 10.5-2.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: common_aboutmembers; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.common_aboutmembers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    institution character varying(100) NOT NULL,
    degree character varying(20) NOT NULL,
    profession character varying(100) NOT NULL,
    team_role character varying(100) NOT NULL,
    headshot character varying(100) NOT NULL,
    team_department character varying(100) NOT NULL
);


ALTER TABLE public.common_aboutmembers OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_aboutmembers_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.common_aboutmembers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.common_aboutmembers_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_aboutmembers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.common_aboutmembers_id_seq OWNED BY public.common_aboutmembers.id;


--
-- Name: common_career; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.common_career (
    id integer NOT NULL,
    posting_link character varying(200) NOT NULL,
    career_location character varying(250) NOT NULL,
    career_role character varying(250) NOT NULL,
    company_id integer NOT NULL
);


ALTER TABLE public.common_career OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_career_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.common_career_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.common_career_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_career_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.common_career_id_seq OWNED BY public.common_career.id;


--
-- Name: common_company; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.common_company (
    id integer NOT NULL,
    company_logo character varying(100) NOT NULL,
    company_name character varying(250) NOT NULL,
    company_description character varying(1000) NOT NULL,
    company_link character varying(200) NOT NULL
);


ALTER TABLE public.common_company OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_company_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.common_company_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.common_company_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.common_company_id_seq OWNED BY public.common_company.id;


--
-- Name: common_seminar; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.common_seminar (
    id integer NOT NULL,
    term character varying(4) NOT NULL,
    description text NOT NULL,
    recap text NOT NULL,
    event_date date NOT NULL,
    location text NOT NULL
);


ALTER TABLE public.common_seminar OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_seminar_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.common_seminar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.common_seminar_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_seminar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.common_seminar_id_seq OWNED BY public.common_seminar.id;


--
-- Name: common_updates; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.common_updates (
    id integer NOT NULL,
    type_of_update character varying(1) NOT NULL,
    title character varying(250) NOT NULL,
    description text NOT NULL,
    image character varying(100) NOT NULL,
    article_link character varying(200) NOT NULL,
    publication_date date NOT NULL
);


ALTER TABLE public.common_updates OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.common_updates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.common_updates_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: common_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.common_updates_id_seq OWNED BY public.common_updates.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO "VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: common_aboutmembers id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_aboutmembers ALTER COLUMN id SET DEFAULT nextval('public.common_aboutmembers_id_seq'::regclass);


--
-- Name: common_career id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_career ALTER COLUMN id SET DEFAULT nextval('public.common_career_id_seq'::regclass);


--
-- Name: common_company id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_company ALTER COLUMN id SET DEFAULT nextval('public.common_company_id_seq'::regclass);


--
-- Name: common_seminar id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_seminar ALTER COLUMN id SET DEFAULT nextval('public.common_seminar_id_seq'::regclass);


--
-- Name: common_updates id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_updates ALTER COLUMN id SET DEFAULT nextval('public.common_updates_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	healthainetwork@gmail.com	t	t	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add content type	3	add_contenttype
8	Can change content type	3	change_contenttype
9	Can delete content type	3	delete_contenttype
10	Can add session	4	add_session
11	Can change session	4	change_session
12	Can delete session	4	delete_session
13	Can add site	5	add_site
14	Can change site	5	change_site
15	Can delete site	5	delete_site
16	Can add log entry	6	add_logentry
17	Can change log entry	6	change_logentry
18	Can delete log entry	6	delete_logentry
19	Can add email address	7	add_emailaddress
20	Can change email address	7	change_emailaddress
21	Can delete email address	7	delete_emailaddress
22	Can add email confirmation	8	add_emailconfirmation
23	Can change email confirmation	8	change_emailconfirmation
24	Can delete email confirmation	8	delete_emailconfirmation
25	Can add social account	9	add_socialaccount
26	Can change social account	9	change_socialaccount
27	Can delete social account	9	delete_socialaccount
28	Can add social application	10	add_socialapp
29	Can change social application	10	change_socialapp
30	Can delete social application	10	delete_socialapp
31	Can add social application token	11	add_socialtoken
32	Can change social application token	11	change_socialtoken
33	Can delete social application token	11	delete_socialtoken
34	Can add user	12	add_user
35	Can change user	12	change_user
36	Can delete user	12	delete_user
67	Can add about members	34	add_aboutmembers
68	Can change about members	34	change_aboutmembers
69	Can delete about members	34	delete_aboutmembers
70	Can add career	35	add_career
71	Can change career	35	change_career
72	Can delete career	35	delete_career
73	Can add updates	36	add_updates
74	Can change updates	36	change_updates
75	Can delete updates	36	delete_updates
100	Can add Company	67	add_company
101	Can change Company	67	change_company
102	Can delete Company	67	delete_company
103	Can add seminar	68	add_seminar
104	Can change seminar	68	change_seminar
105	Can delete seminar	68	delete_seminar
\.


--
-- Data for Name: common_aboutmembers; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.common_aboutmembers (id, name, institution, degree, profession, team_role, headshot, team_department) FROM stdin;
2	Danielle Kellier	U.Penn		MD '22	VP	Danielle_Kellier.jpg	Web Development
3	H. Christy Hong	U.Penn		MD/MBA '19	Founder & Co-President	Christy_Hong.jpg	
4	Lucy Yin	U.Penn		MS/MBA '19	Founder & Co-President	Lucy_Yin.png	
5	Radhika Gupta	Columbia		BA '16	VP	Radhika_Gupta.png	AI News
6	Elston He	U.Penn		MD/MBA '20	Chief Strategy Officer	Elston_He.jpg	
7	Dan Kim	U.Penn		MBA '19	VP	Daniel_D_Kim.jpg	Business Development
8	Hongyi Yan	U.Penn		MBA '20	VP	Hongyi_Yan.JPG	Career Development
9	Ahmed Aly	U.Penn		MD/PhD '21	Director	Ahmed_Aly.jpg	Health AI Labs
10	Antonio Hernandez	Stanford		BA '16	Partner @ UCSF	Antonio_Hernandez.jpg	
27	Zachary Hay	U.Penn		BS '19	Director of Incubator	Zachary_Hay.jpg	Health AI Labs
1	Anjali Maheshwari	U.Penn		BSE '21	AVP	Anjali_Maheshwari.jpg	Web Development
28	Rose Schlenk	U.Penn		M:IPD '19	VP	Rosalie_Schlenk.jpg	Design
12	So Yoshida	U.Penn		MBA '20	VP	So_Yoshida.jpg	Finance
13	Natalie Pancer	U.Penn		MBA '20	VP	Natalie_Pancer.jpg	Marketing
14	Evan Strother	U.Penn		MBA '20	VP	Evan_Strother.jpg	Membership
15	Sophie Alpert	U.Penn		MBA '20	VP	Sophie_Alpert.png	Speaker Series
16	Chaitanya Asawa	Stanford		BS '18	Partner @ Stanford	Chaitanya_Asawa.jpg	
17	Cindy Zang Liu	Stanford		BS '19	Partner @ Stanford	Cindy_Liu.jpg	
18	Neal Atul Patel	Stanford		BS/MS '19	Partner @ Stanford	Neal_Patel.jpg	
19	Jason Ku Wang	Stanford		BS '18	Partner @ Stanford	Jason_Wang.jpg	
20	John Barbieri	PennMed	MD/MBA	Physician	Clinal Curator	John_Barbieri.jpg	
21	Laura Croft	Gartner		Research Director	Advisor	Laura_Croft.png	
22	Mike Draugelis	PennMed		Chief Data Scientist	Advisor	Mike_Draugelis.png	
24	John Glaser	Cerner	PhD	Senior VP, Population Health	Advisor	John_Glaser.jpg	
25	Zachary Ives	U.Penn	PhD	Adani President's Distinguished Professor and Chair	Advisor	Zachary_Ives.jpg	
26	Dan Roth	U.Penn	PhD	Eduardo D. Glandt Distinguished Professor	Advisor	Dan_Roth.png	
32	Jason H. Moore	U.Penn	PhD	Director, Institute for Biomedical Informatics	Advisor	Jason_H_Moore.jpg	
30	Regina Lee	U.Penn		MA/MBA '20	VP	Regina_Lee.jpg	Speaker Series
29	Agi Kajanaku	Arcadia		BA '16	Member	Agi_Kajanaku.jpg	Health AI Labs
11	Vishnu Rachakonda	U.Penn		MS '19	Member	Vishnu_Rachakonda.jpg	Health AI Labs
23	Eli Cornblath	U.Penn		MD/PhD '23	Director of Data Challenge	Eli_Cornblath.jpg	Health AI Labs
\.


--
-- Data for Name: common_career; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.common_career (id, posting_link, career_location, career_role, company_id) FROM stdin;
1	https://github.com/pigment/fake-logos/tree/gh-pages/logos	San Francisco, CA	Tipper Typer	1
2	https://github.com/pigment/fake-logos/tree/gh-pages/logos	Madison, WI	Doodler	1
3	https://lizzyr1996.myportfolio.com/beer-logo-brand	Philadelphia, PA	Doodler	2
4	https://lizzyr1996.myportfolio.com/beer-logo-brand	Madison, WI	Tipper Typer	2
\.


--
-- Data for Name: common_company; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.common_company (id, company_logo, company_name, company_description, company_link) FROM stdin;
1	fast-banana.png	Fast Banana	Fake dummy company description	https://github.com/pigment/fake-logos
2	bacchus.png	Bacchus	Beer company	https://lizzyr1996.myportfolio.com/beer-logo-brand
\.


--
-- Data for Name: common_seminar; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.common_seminar (id, term, description, recap, event_date, location) FROM stdin;
1	1808	<p><span style="color: #818181; font-family: Montserrat; letter-spacing: 0.32px; font-size: large;"><span style="font-weight: bold;">Artificial Intelligence in healthcare 101</span></span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Speakers:</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Charles Kahn, Jr., MD, MS&nbsp;</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">(Radiology, Penn Medicine)&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Eric Eaton, PhD</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(Computer and Information Science, UPenn)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">​</span><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Hany Saleeb, PhD&nbsp;</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">(IBM Watson Health)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Moderator:&nbsp;Lucy Yin</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Partners: Wharton Digital Health Club, Health Care Club, Penn Health X</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><em style="position: relative; color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Lunch served.</em></p>	<p><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.youtube.com/watch?v=_jzjnJqxyuE" target="_blank" rel="noopener">Webcast</a><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">​</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://docs.google.com/presentation/d/1erQFHsLsBEvEW-yE6uPyG8ahoB_q9Wk8uuIvwXNCMyk/edit?usp=sharing" target="_blank" rel="noopener">Recap<br /><br />​</a><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://drive.google.com/open?id=1qtr46J8KNMNrYhNEbUgNw2C54_eUPMdc" target="_blank" rel="noopener">Photos</a></p>	2018-09-27	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Time: 12:15 - 1:15pm</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Location: Room F85,</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.google.com/maps/place/Jon+M.+Huntsman+Hall,+3730+Walnut+St,+Philadelphia,+PA+19104/data=!4m2!3m1!1s0x89c6c65832da4783:0x7427cd7df674a321?ved=2ahUKEwjqnNL3kb3eAhXQmeAKHSKuA5EQ8gEwAHoECAAQAQ" target="_blank" rel="noopener">Jon M. Huntsman Hall</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(3730 Walnut St)&nbsp;</span></p>
2	1808	<p><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><span style="font-size: large;">Leveraging AI to solve problems in healthcare</span></strong><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Speakers:<span style="font-weight: bold;">&nbsp;</span></span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Daniel Herman, MD, PhD</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><span style="font-size: medium;">(</span><span style="font-size: small;">Pathology &amp; Laboratory Medicine,&nbsp;</span><span style="font-size: medium;">Penn Medicine)&nbsp;</span></span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Donald Rucker, MD</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(National Coordinator for Health IT, ONC/HHS)&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Michael Draugelis</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(Chief Data Scientist, Penn Medicine)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Moderator:&nbsp;Christy Hong</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Partners:&nbsp;</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Penn Health X,&nbsp;</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Wharton&nbsp;</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Digital Health Club,&nbsp;</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Health Care Club</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><em style="position: relative; color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Lunch served.</em></p>	<p><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.youtube.com/watch?v=4PUdGjcHiK8" target="_blank" rel="noopener">Webcast</a><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Recap (</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://drive.google.com/file/d/169iLf4f1bz6Se_0m-0ORdU7PEDP-5Dyv/view?usp=sharing" target="_blank" rel="noopener">1</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;and&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://drive.google.com/file/d/1SaGHNUZbZDvwzFRSHCPkxbe4xAzct_li/view?usp=sharing" target="_blank" rel="noopener">2</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://drive.google.com/open?id=1aIOsN7RMmXGWRyuxVvmsaxDU1wXkIB3Q" target="_blank" rel="noopener">Photos</a><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://drive.google.com/open?id=1aIOsN7RMmXGWRyuxVvmsaxDU1wXkIB3Q" target="_blank" rel="noopener">​​</a></p>	2018-10-10	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Time: 12:00 - 1:15pm&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Location:&nbsp;<a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s;" href="https://www.google.com/maps/place/Perelman+Quadrangle/@39.9509217,-75.1939057,15z/data=!4m2!3m1!1s0x0:0x804398fb45155bb1?sa=X&amp;ved=2ahUKEwjSnp2O9eXdAhUBNd8KHUVhA0UQ_BIwDnoECAoQCw" target="_blank" rel="noopener">Class of 49 Auditorium, Houston Hall</a></span></p>
3	1808	<p><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><span style="font-size: large;">Machine Learning Coding Workshop</span></strong><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Led by<span style="font-weight: bold;">&nbsp;</span></span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Ahmed Aly, Eli Cornblath, Vishnu Rachakonda, &amp; Zach Hay</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Partners: Penn Health X &amp; Wharton Analytics Club</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><em style="position: relative; color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">​Lunch served.</em></p>	<p><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.youtube.com/watch?v=Uru851_3D60" target="_blank" rel="noopener">Webcast</a><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://docs.google.com/presentation/d/125icRIQO-IW0HlCvpuABOV_v2ZnU5TNiqvhLYhhHJJ0/edit?usp=sharing" target="_blank" rel="noopener">Recap</a><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://drive.google.com/drive/folders/14-Qmog3Yp9wMGFEM1qQ2HkcnVdWCME8D?usp=sharing" target="_blank" rel="noopener">Photos</a></p>	2018-10-24	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Time: 12:00 - 1:00pm&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Location: Room&nbsp;513,&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.facilities.upenn.edu/maps/locations/jordan-medical-education-center" target="_blank" rel="noopener">Jordan Medical Education Center&nbsp;(JMEC)</a></p>
4	1808	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><span style="font-weight: bold;"><span style="font-size: large;">Provider panel</span></span></span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Speakers:&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Bill Hanson, MD</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(CMIO, Penn Medicine)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Gary Kurtzman, MD</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(Managing Director, Safeguard)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Katherine Choi, MD</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(Clinical Innovation Manager, Penn Medicine Center for Health Care Innovation)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Moderator: Regina Lee</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Partners: Penn Health X &amp; Wharton Digital Health Club</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><em style="position: relative; color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Lunch served.</em></p>	<p><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.youtube.com/watch?v=Uru851_3D60" target="_blank" rel="noopener">Webcast</a><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Recap (</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://docs.google.com/document/d/19PbJ9kLNCIhA7yMTSfaL7Q9Fc1WXpv5dJeOODPa0QiE/edit?usp=sharing" target="_blank" rel="noopener">notes</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;and&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://docs.google.com/document/d/19PbJ9kLNCIhA7yMTSfaL7Q9Fc1WXpv5dJeOODPa0QiE/edit?usp=sharing" target="_blank" rel="noopener">slides</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">)</span></p>	2018-11-06	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Time: 12:00 - 1:00pm</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Location: Room 365,&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.google.com/maps/place/Jon+M.+Huntsman+Hall,+3730+Walnut+St,+Philadelphia,+PA+19104/data=!4m2!3m1!1s0x89c6c65832da4783:0x7427cd7df674a321?ved=2ahUKEwjqnNL3kb3eAhXQmeAKHSKuA5EQ8gEwAHoECAAQAQ" target="_blank" rel="noopener">Jon M. Huntsman Hall</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(3730 Walnut St)&nbsp;</span></p>
5	1808	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><span style="font-weight: bold;"><span style="font-size: large;">Health AI startup founders &amp; VC investor panel</span></span></span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Speakers:&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Andrew Le, MD MBA</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(CEO &amp; Co-founder,&nbsp;</span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s;" href="https://www.buoyhealth.com/" target="_blank" rel="noopener">Buoy Health</a></span><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">)</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Sundeep Bhan&nbsp;</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">(CEO &amp; Co-founder,&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="http://www.prognos.ai/" target="_blank" rel="noopener">Prognos</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">)&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Ethan Wergelis-Isaacson&nbsp;</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">(</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="http://www.dreamit.com/" target="_blank" rel="noopener">Dreamit HealthTech</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">)&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">John Prendergass</strong><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">&nbsp;(</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.sep.benfranklin.org/" target="_blank" rel="noopener">Ben Franklin Tech Partners</a><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">)&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">​Partners: Penn Health X&nbsp; &amp; Wharton Digital Health Club&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><strong style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;"><em style="position: relative;"><span style="color: #248d6c;">Followed by networking happy hour&nbsp;</span></em></strong></p>		2018-11-14	<p><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Time: 4:00 - 5:30pm&nbsp;</span><br style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" /><span style="color: #818181; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;">Location:&nbsp;</span><a style="text-decoration-line: none; opacity: 0.7; border-bottom: 1px solid rgba(0, 0, 0, 0.5); transition: opacity 200ms ease-in-out 0s; font-family: Montserrat; font-size: 16px; letter-spacing: 0.32px;" href="https://www.google.com/maps/place/Perelman+Quadrangle/@39.9509217,-75.1939057,15z/data=!4m2!3m1!1s0x0:0x804398fb45155bb1?sa=X&amp;ved=2ahUKEwjSnp2O9eXdAhUBNd8KHUVhA0UQ_BIwDnoECAoQCw" target="_blank" rel="noopener">Class of 49 Auditorium, Houston Hall</a></p>
\.


--
-- Data for Name: common_updates; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.common_updates (id, type_of_update, title, description, image, article_link, publication_date) FROM stdin;
22	B		<p>Calling all movers & shakers. Google is hosting a $25M global competition to develop AI that is beneficial for humanity</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.theverge.com/2018/10/29/18038918/google-ai-social-good-impact-challenge-global-competition">See more here</a>.</p>	google-25.jpg	https://www.theverge.com/2018/10/29/18038918/google-ai-social-good-impact-challenge-global-competition	2018-10-29
23	B		<p>Sopris Health, a medical documentation healthcare startup, raises $3.4M</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.mobihealthnews.com/content/medical-documentation-ai-system-sopris-health-raises-34m">See more here</a>.</p>	sopris.jpg	https://www.mobihealthnews.com/content/medical-documentation-ai-system-sopris-health-raises-34m	2018-10-29
25	B		<p>Women’s Health Health Platform, Flo, raises $12M in Series A funding</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.mobihealthnews.com/content/ai-powered-womens-health-platform-lands-12m-series-extension-round">See more here</a>.</p>	ai-powered.png	https://www.mobihealthnews.com/content/ai-powered-womens-health-platform-lands-12m-series-extension-round	2018-10-22
5	C		<p>AI in Mental Health Care: How AI is being applied to improve mental health care and to help call center workers be more human.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.popsci.com/artificial-intelligence-mental-health">See more here</a>.</p>	apple-watch.jpg	https://www.popsci.com/artificial-intelligence-mental-health	2018-10-22
6	C		<p>Jack Karsten and Darrell West discuss how the influx of medical data from wearable devices can improve health care costs and outcomes.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.brookings.edu/blog/techtank/2018/10/18/wearable-device-data-and-ai-can-reduce-health-care-costs-and-paperwork/">See more here</a>.</p>	health.jpg	https://www.brookings.edu/blog/techtank/2018/10/18/wearable-device-data-and-ai-can-reduce-health-care-costs-and-paperwork/	2018-10-22
8	C		<p>HIPAA: Guidance on rules that will continue to matter for patient data sharing</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.healthcareitnews.com/news/hipaa-and-data-sharing-rethinking-both-digital-age">See more here</a>.</p>	hipaa.jpeg	https://www.healthcareitnews.com/news/hipaa-and-data-sharing-rethinking-both-digital-age	2018-10-15
9	C		<p>Academic medical centers and tech vendor partner use AI to create “synthetic MRIs”</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.beckershospitalreview.com/artificial-intelligence/mayo-clinic-mass-general-nvidia-researchers-use-ai-to-create-synthetic-mris.html">See more here</a>.</p>	synth-mri_orig.jfif	https://www.beckershospitalreview.com/artificial-intelligence/mayo-clinic-mass-general-nvidia-researchers-use-ai-to-create-synthetic-mris.html	2018-10-07
12	C		<p>AI can be used to detect diabetic retinopathy if it can overcome challenges to translate these types of AI applications to real-world clinical practices</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.nature.com/articles/s41746-018-0040-6">See more here</a>.</p>	diabetic-retinopathy.jpg	https://www.nature.com/articles/s41746-018-0040-6	2018-09-30
10	C		<p>An often overlooked aspect of AI applications is how they can fit into clinical practice. This viewpoint discusses some important considerations with respect to the implementation of recent AI advances in dermatology.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://jamanetwork.com/journals/jamadermatology/article-abstract/2697219">See more here</a>.</p>	skin-cancer-screen_1.jpg	https://jamanetwork.com/journals/jamadermatology/article-abstract/2697219	2018-10-07
15	C		<p>A radiologist's perspective on AI, and why we should be encouraged, not scared.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://link.springer.com/article/10.1007/s00330-018-5644-3">See more here</a>.</p>	radiology.jpg	https://link.springer.com/article/10.1007/s00330-018-5644-3	2018-09-17
14	C		<p>Healthcare chatbot for children is on its way: Buoy partnering with Boston Children’s</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.mobihealthnews.com/content/boston-childrens-buoy-health-embark-learning-partnership-teach-buoys-ai-about-kids">See more here</a>.</p>	buoy.png	https://www.mobihealthnews.com/content/boston-childrens-buoy-health-embark-learning-partnership-teach-buoys-ai-about-kids	2018-10-23
17	C		<p>Rather than competing to prove whether AI or clinicians are better, we should work together to identify how much more we can accomplish as a team than on our own</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.washingtonpost.com/news/grade-point/wp/2018/06/12/forget-man-vs-machine-when-doctors-compete-with-artificial-intelligence-patients-lose/?noredirect=on&utm_term=.9ef4a16247c7">See more here</a>.</p>	man-v-machine.jpeg	https://www.washingtonpost.com/news/grade-point/wp/2018/06/12/forget-man-vs-machine-when-doctors-compete-with-artificial-intelligence-patients-lose/?noredirect=on&utm_term=.9ef4a16247c7	2018-09-09
18	C		<p>Over the summer, the AMA adopted a new policy setting standards for its approach to the use of AI. AI is definitely coming to health care. The question is, who’s going to make those rules?</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://wire.ama-assn.org/ama-news/health-care-ai-holds-promise-physicians-perspective-needed">See more here</a>.</p>	ama.png	https://wire.ama-assn.org/ama-news/health-care-ai-holds-promise-physicians-perspective-needed	2018-09-09
26	B		<p>Funding for Robotic Surgery - Gauss Surgical raises 20M in Series C Funding Round. 8 / 10 investors were health systems</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.beckershospitalreview.com/artificial-intelligence/ai-driven-health-tech-firm-gauss-surgical-raises-20m-8-health-systems-are-investors-in-funding-round.html">See more here</a>.</p>	gauss-surgical-300x230.png	https://www.beckershospitalreview.com/artificial-intelligence/ai-driven-health-tech-firm-gauss-surgical-raises-20m-8-health-systems-are-investors-in-funding-round.html	2018-10-22
13	C		<p>Robotic Surgeons? Automated robots are not trying to remove the human from the surgical team but to (1) enhance the efficacy of a surgery, and (2) generate new surgical approaches</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://arxiv.org/pdf/1707.03080.pdf">See more here</a>.</p>	da-vinci-robot-trans-nvbqzqnjv4bqedupgwxtgvtbfymamlyatm4ovimmp-5wstnaigczty4.jpg	https://arxiv.org/pdf/1707.03080.pdf	2018-09-23
28	B		<p>AI applications are starting to fill healthcare needs in resource-poor settings despite questionable accuracy of the tools. Is something better than nothing?</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.bloomberg.com/news/articles/2018-10-10/gates-foundation-backs-self-checkup-app-s-expansion-in-africa">See more here</a>.</p>	accuracy_orig.jpeg	https://www.bloomberg.com/news/articles/2018-10-10/gates-foundation-backs-self-checkup-app-s-expansion-in-africa	2018-10-15
29	B		<p>Industry view: AI healthcare startups have raised $4.3B in funding since 2013</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://venturebeat.com/2018/09/13/cb-insights-ai-health-care-startups-have-raised-4-3-billion-since-2013/">See more here</a>.</p>	download_orig.jfif	https://venturebeat.com/2018/09/13/cb-insights-ai-health-care-startups-have-raised-4-3-billion-since-2013/	2018-10-08
32	B		<p>Proscia, a pioneer in the development of digital pathology AI, closed an $8.3M series A funding rounds.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.businesswire.com/news/home/20180926005198/en/Proscia-Closes-8.3M-Series-Financing">See more here</a>.</p>	proscia_1_orig.jpeg	https://www.businesswire.com/news/home/20180926005198/en/Proscia-Closes-8.3M-Series-Financing	2018-09-30
33	B		<p>Nuance has partnered with Epic to create AI-enabled virtual assistants to allow doctors to make orders in electronic health systems (e.g., lab systems, EHR) through voice commands</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.healthdatamanagement.com/news/epic-nuance-collaborate-to-add-ai-enabled-virtual-assistance">See more here</a>.</p>	nuance.png	https://www.healthdatamanagement.com/news/epic-nuance-collaborate-to-add-ai-enabled-virtual-assistance	2018-09-23
35	B		<p>"The chatbot will see you now."  Syllable.ai, a health-chat platform startup, raises most of their $13.7M funding round.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://news.crunchbase.com/news/syllable-ai-xoogler-led-health-chat-platform-raises-most-of-13-7m-round/">See more here</a>.</p>	healthcare.png	https://news.crunchbase.com/news/syllable-ai-xoogler-led-health-chat-platform-raises-most-of-13-7m-round/	2018-09-17
36	B		<p>Expanding reach: large companies, like Cigna, are increasingly creating venture arms to partner with smaller, innovative startups, in the health AI space and beyond.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.healthcarefinancenews.com/news/cigna-ventures-invest-250-million-healthcare-startups">See more here</a>.</p>	coins-and-trees-in-hands-1.jpg	https://www.healthcarefinancenews.com/news/cigna-ventures-invest-250-million-healthcare-startups	2018-09-17
37	B		<p>How one hospital used Ayasdi’s AI to improve its clinical variation problem within pneumonia and sepsis.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://medcitynews.com/2018/07/hospital-ayasdis-ai/?rf=1">See more here</a>.</p>	ayasai-ai.jpg	https://medcitynews.com/2018/07/hospital-ayasdis-ai/?rf=1	2018-09-09
39	B		<p>HealthX: receives funding for drug discovery / re-purposing platform.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://medcitynews.com/2018/07/ai-based-healx-raises-10-million-for-drug-discovery/?utm_campaign=MCN%20Daily%20Top%20Stories&utm_source=hs_email&utm_medium=email&utm_content=64797311&_hsenc=p2ANqtz-9">See more here</a>.</p>	healx.jpg	https://medcitynews.com/2018/07/ai-based-healx-raises-10-million-for-drug-discovery/?utm_campaign=MCN%20Daily%20Top%20Stories&utm_source=hs_email&utm_medium=email&utm_content=64797311&_hsenc=p2ANqtz-9	2018-09-09
41	T		<p>21st Century Cures Act Health IT Provisions Promotes Interoperability and Data Exchange</p>\r\n<p>&nbsp;</p>\r\n<p><a href="http://thehealthcareblog.com/blog/2018/10/16/ensuring-that-the-21st-century-cures-act-health-it-provisions-promote-interoperability-and-data-exchange/">See more here</a>.</p>	21-century-cures.png	http://thehealthcareblog.com/blog/2018/10/16/ensuring-that-the-21st-century-cures-act-health-it-provisions-promote-interoperability-and-data-exchange/	2018-10-29
43	T		<p>Next generation Natural Language Processing from Google, vastly outperforming previous algorithms on industry benchmarks.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://arxiv.org/abs/1810.04805">See more here</a>.</p>	nlp.jpeg	https://arxiv.org/abs/1810.04805	2018-10-22
44	T		<p>“Why Should I Trust You?” Explaining the Predictions of Any Classifier.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://arxiv.org/pdf/1602.04938.pdf">See more here</a>.</p>	classifier.jpeg	https://arxiv.org/pdf/1602.04938.pdf	2018-10-22
45	T		<p>A Guide to ML for Difficult Projects: How to Deliver</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://blog.insightdatascience.com/how-to-deliver-on-machine-learning-projects-c8d82ce642b0">See more here</a>.</p>	machine_orig.jpeg	https://blog.insightdatascience.com/how-to-deliver-on-machine-learning-projects-c8d82ce642b0	2018-10-15
46	T		<p>What are machine learning algorithms really picking up on in medical images? This study by Finlayson et al. shows that subtle changes to images that are imperceptible by humans can completely fool a computer vision algorithm. The authors also discuss why certain actors in the healthcare space may be incentivized to falsify data and fool these algorithms.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://arxiv.org/pdf/1804.05296.pdf">See more here</a>.</p>	medical-images.jpg	https://arxiv.org/pdf/1804.05296.pdf	2018-10-15
48	T		<p>Google introduced a companion to Google Scholar called Google Dataset search. It will allow researchers and scientists to search through a wide variety of open source data sets. It is currently in Beta.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.theverge.com/platform/amp/2018/9/5/17822562/google-dataset-search-service-scholar-scientific-journal-open-data-access%20https://toolbox.google.com/datasetsearch">See more here</a>.</p>	acastro-180508-1777-google-io-0003-0.jpg	https://www.theverge.com/platform/amp/2018/9/5/17822562/google-dataset-search-service-scholar-scientific-journal-open-data-access%20https://toolbox.google.com/datasetsearch	2018-10-07
49	T		<p>Knowing ground truth is critical for training any supervised machine learning algorithm. However, in practice, we often can’t ensure that our training labels are perfect. Han et al. have generated “a meta algorithm called Pumpout to overcome the problem of memorizing noisy labels.”</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://arxiv.org/pdf/1809.11008.pdf">See more here</a>.</p>	borderline.png	https://arxiv.org/pdf/1809.11008.pdf	2018-10-07
50	T		<p>DARPA recently launched a new initiative -  Lifelong Learning Machines (L2M) programs - draws inspiration from biological systems and  seeks to develop fundamentally new ML approaches that allow systems to adapt continually to new circumstances without forgetting previous learning.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.darpa.mil/news-events/2018-05-03">See more here</a>.</p>	darpa.jpg	https://www.darpa.mil/news-events/2018-05-03	2018-10-30
52	T		<p>What about my HIPPA data?! Amazon Web Services (AWS), an extremely popular cloud computing platform, is forging its way into Healthcare. Healthcare professionals can use AWS to process their HIPPA protected information with these guidelines.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://aws.amazon.com/health/healthcare-compliance/hipaa/">See more here</a>.</p>	diagram-healthcare-compliance-v2-0d7d4cb1a3932c22d8bb7ae2c6fa10a3eb37af77.png	https://aws.amazon.com/health/healthcare-compliance/hipaa/	2018-09-17
53	T		<p>Study finds that substantial differences exist across the common results of cardiac imaging modalities.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2698631">See more here</a>.</p>	cardiac-imaging.png	https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2698631	2018-09-17
54	T		<p>Sharing models instead of data: a potential remedy for medical data sharing problem?</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://academic.oup.com/jamia/article/25/8/945/4956468#.W1dylyjBflQ.twitter">See more here</a>.</p>	images.png	https://academic.oup.com/jamia/article/25/8/945/4956468#.W1dylyjBflQ.twitter	2018-09-16
20	B		<p>Visla Labs raises $3M in funding from Lux Capital to further development of AI-based radiology diagnostics platform</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.healthdatamanagement.com/news/visla-labs-raises-3m-in-funding-to-fuel-ai-use-in-radiology">See more here</a>.</p>	visla-labs.jpeg	https://www.healthdatamanagement.com/news/visla-labs-raises-3m-in-funding-to-fuel-ai-use-in-radiology	2018-11-05
21	B		<p>How AI might disrupt the workforce: Ramifications of automation on jobs and the economy</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.brookings.edu/blog/techtank/2018/04/18/will-robots-and-ai-take-your-job-the-economic-and-political-consequences-of-automation/">See more here</a>.</p>	employment-gap.jpg	https://www.brookings.edu/blog/techtank/2018/04/18/will-robots-and-ai-take-your-job-the-economic-and-political-consequences-of-automation/	2018-11-05
24	B		<p>Anthem nabs Google, Amazon vet as head of its new AI group - MedCity News</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://medcitynews.com/2018/10/report-anthem-nabs-google-amazon-vet-as-head-of-its-new-ai-group/?utm_campaign=MCN%20Daily%20Top%20Stories&utm_source=hs_email&utm_medium=email&utm_content=66970604&_hs">See more here</a>.</p>	medcity.jpg	https://medcitynews.com/2018/10/report-anthem-nabs-google-amazon-vet-as-head-of-its-new-ai-group/?utm_campaign=MCN%20Daily%20Top%20Stories&utm_source=hs_email&utm_medium=email&utm_content=66970604&_hs	2018-10-29
4	C		<p>The Trolley Problem on the largest scale. After gathering 40 million decisions from millions of individuals in 233 countries, we are still only beginning to scratch the surface of developing an ethical framework for when artificial intelligence applications have to make moral choices.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.nature.com/articles/s41586-018-0637-6">See more here</a>.</p>	trolley.png	https://www.nature.com/articles/s41586-018-0637-6	2018-10-29
7	C		<p>Cybersecurity threats to health care organizations are real; 9 out of 10 hospitals were attacked over the past two years. How should organizations proactively approach cybersecurity?</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://journals.lww.com/frontiersonline/Abstract/2018/09000/Enterprise_Cybersecurity___Building_a_Successful.3.aspx">See more here</a>.</p>	cyber-security.jpeg	https://journals.lww.com/frontiersonline/Abstract/2018/09000/Enterprise_Cybersecurity___Building_a_Successful.3.aspx	2018-10-15
11	C		<p>​September 30, 2018  Murky incentives and missing regulations surround the partnership between Paige.AI, a startup focusing on use of AI in cancer diagnoses, and Memorial Sloan-Kettering. ProPublica and the NYT investigate.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.beckershospitalreview.com/healthcare-information-technology/nyt-propublica-memorial-sloan-kettering-s-partnership-with-paige-ai-may-be-a-conflict-of-interest-6-things-to-know.html">See more here</a>.</p>	paige_orig.jpg	https://www.beckershospitalreview.com/healthcare-information-technology/nyt-propublica-memorial-sloan-kettering-s-partnership-with-paige-ai-may-be-a-conflict-of-interest-6-things-to-know.html	2018-09-30
16	C		<p>Although we often look at AI in medicine as a diagnostic tool, voice-powered virtual assistants could play a diverse role: from diagnosing illness based on speech patterns to providing patients with real-time coaching and support.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(18)31803-8.pdf">See more here</a>.</p>	virtual-assistant.jpg	https://www.thelancet.com/pdfs/journals/lancet/PIIS0140-6736(18)31803-8.pdf	2018-09-17
19	C		<p>AI can democratize surgery and improve access and quality of care: a brief editorial commenting on potential opportunities</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028471/pdf/icu-59-221.pdfhttps://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028471/pdf/icu-59-221.pdf">See more here</a>.</p>	surgery-robot_1.jpg	https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028471/pdf/icu-59-221.pdfhttps://www.ncbi.nlm.nih.gov/pmc/articles/PMC6028471/pdf/icu-59-221.pdf	2018-09-09
27	B		<p>The healthcare AI industry is estimated to reach $10B by 2024. Who will capture the most growth</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.marketwatch.com/press-release/over-40-cagr-healthcare-artificial-intelligence-market-to-reach-10-billion-by-2024-2018-09-14">See more here</a>.</p>	cagr-300x229.jpg	https://www.marketwatch.com/press-release/over-40-cagr-healthcare-artificial-intelligence-market-to-reach-10-billion-by-2024-2018-09-14	2018-10-15
30	B		<p>Bigger Series A - IDx raises $33MM off the back of FDA approval from 8VC + Optum Ventures</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.prnewswire.com/news-releases/ai-diagnostics-company-idx-secures-significant-funding-from-8vc-optum-ventures-300718104.html">See more here</a>.</p>	1_1.jpg	https://www.prnewswire.com/news-releases/ai-diagnostics-company-idx-secures-significant-funding-from-8vc-optum-ventures-300718104.html	2018-10-08
31	B		<p>Huami, the second largest wearable company globally, announced the release of a new custom, low-powered AI chip, which comes integrated with 4 AI engines that support cardiac biometric capabilities and abnormality monitoring, in a move that further cements its position as a leader in health-based smartwatches.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.businesswire.com/news/home/20180918005967/en/">See more here</a>.</p>	huaim.jpeg	https://www.businesswire.com/news/home/20180918005967/en/	2018-09-30
34	B		<p>Ever been burned by WebMD? K-Health, a startup who uses AI to view previous diagnoses and give you a more “nuanced” view of that stomach ache / rash / cough, raises $12.5M</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://news.crunchbase.com/news/wix-board-member-raises-12-5m-for-k-health-an-ai-powered-primary-care-application/">See more here</a>.</p>	246x0w.jpg	https://news.crunchbase.com/news/wix-board-member-raises-12-5m-for-k-health-an-ai-powered-primary-care-application/	2018-09-23
55	T		<p>A recent study shows high accuracy and scalability of deep learning of electronic health records.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.nature.com/articles/s41746-018-0029-1">See more here</a>.</p>	emr.jpg	https://www.nature.com/articles/s41746-018-0029-1	2018-09-09
1	C		<p>AI could be a promising non-invasive way cheaper modality for lung cancer screening (higher sensitivity than Chest X-ray, higher PPV than CT scan).</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0205264">See more here</a>.</p>	lung-cancer.jpg	https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0205264	2018-11-05
2	C		<p>Perspectives: Jack Karsten and Darrell West discuss how the influx of medical data from wearable devices can improve health care costs and outcomes.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.brookings.edu/blog/techtank/2018/10/18/wearable-device-data-and-ai-can-reduce-health-care-costs-and-paperwork/">See more here</a>.</p>	wearable.jpg	https://www.brookings.edu/blog/techtank/2018/10/18/wearable-device-data-and-ai-can-reduce-health-care-costs-and-paperwork/	2018-11-05
38	B		<p>Corti AI: How a Danish startup that can help 911 operators better diagnose cardiac arrest via NLP/AI.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.bloomberg.com/news/articles/2018-06-20/the-ai-that-spots-heart-attacks">See more here</a>.</p>	corti.jpeg	https://www.bloomberg.com/news/articles/2018-06-20/the-ai-that-spots-heart-attacks	2018-09-09
40	T		<p>JAMA Viewpoint emphasizes the importance of interpretability and workflow integration for predictive models in healthcare. The authors describe a framework for evaluating Clinical Decision Support Systems.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://jamanetwork.com/journals/jama/fullarticle/2713901">See more here</a>.</p>	clinical-decision-support.png	https://jamanetwork.com/journals/jama/fullarticle/2713901	2018-11-05
42	T		<p>Qure.ai developed a deep learning model to identify acute findings in head CTs. After training on 290,055 CTs, they achieved above 90% sensitivity and specificity for every acute finding they assessed on a testing set of 21,095 scans. They also demonstrated that their algorithm was as sensitive as a radiologist, albeit not as specific.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.sciencedirect.com/science/article/pii/S0140673618316453?dgcid=rss_sd_all">See more here</a>.</p>	qure-ai.png	https://www.sciencedirect.com/science/article/pii/S0140673618316453?dgcid=rss_sd_all	2018-10-29
47	T		<p>Kaggle is hosting the RSNA pneumonia detection challenged based on the NIH Chest X-ray data set comprising 112,120 X-ray images with disease labels from 30,805 unique patients. It is an exciting example of data scientists exploring clinical, open-source data sets.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.kaggle.com/c/rsna-pneumonia-detection-challenge">See more here</a>.</p>	cdortdlwaaimn9o.jpg	https://www.kaggle.com/c/rsna-pneumonia-detection-challenge	2018-10-07
51	T		<p>The AI Next Campaign is a HUGE, $2 billion project that DARPA is undertaking to bring about the so called “3rd generation of AI”. Some of that funding will go to computational biologists.</p>\r\n<p>&nbsp;</p>\r\n<p><a href="https://www.darpa.mil/work-with-us/ai-next-campaign">See more here</a>.</p>	aieconcept-619-316.png	https://www.darpa.mil/work-with-us/ai-next-campaign	2018-09-23
3	C		<p>A recent journal in  "Annals of Internal Medicine" shows how artificial intelligence was used to identify non-neoplastic polyps during colonoscopy to facilitate a “diagnosis and leave” strategy for these benign lesions. Prospective studies of artificial intelligence in medicine are generally lacking and it is nice to see the authors of this work use a prospective design</p>\r\n<p>&nbsp;</p>\r\n<p><a href="http://annals.org/aim/article-abstract/2697089/real-time-use-artificial-intelligence-identification-diminutive-polyps-during-colonoscopy?doi=10.7326%2fM18-0249">See more here</a>.</p>	annals.jpg	http://annals.org/aim/article-abstract/2697089/real-time-use-artificial-intelligence-identification-diminutive-polyps-during-colonoscopy?doi=10.7326%2fM18-0249	2018-10-29
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2018-11-10 19:35:49.584149+00	1	AboutMembers object (1)	1	[{"added": {}}]	34	1
2	2018-11-10 19:40:26.20329+00	2	AboutMembers object (2)	1	[{"added": {}}]	34	1
3	2018-11-10 19:40:31.211471+00	2	AboutMembers object (2)	2	[]	34	1
4	2018-11-12 16:30:59.670927+00	3	H. Christy Hong	1	[{"added": {}}]	34	1
5	2018-11-12 16:31:47.428062+00	4	Lucy Yin	1	[{"added": {}}]	34	1
6	2018-11-12 16:32:36.755516+00	5	Radhika Gupta	1	[{"added": {}}]	34	1
7	2018-11-12 16:33:20.53113+00	6	Elston He	1	[{"added": {}}]	34	1
8	2018-11-12 16:33:49.710026+00	7	Dan Kim	1	[{"added": {}}]	34	1
9	2018-11-12 16:33:59.203037+00	5	Radhika Gupta	2	[]	34	1
10	2018-11-12 16:34:53.262735+00	8	Hongyi Yan	1	[{"added": {}}]	34	1
11	2018-11-12 16:35:34.914516+00	9	Ahmed Aly	1	[{"added": {}}]	34	1
12	2018-11-12 16:36:10.601313+00	10	Eli Cornblath	1	[{"added": {}}]	34	1
13	2018-11-12 20:33:43.77018+00	11	Vishnu Rachakonda	1	[{"added": {}}]	34	1
14	2018-11-12 20:34:26.55459+00	12	So Yoshida	1	[{"added": {}}]	34	1
15	2018-11-12 20:34:55.681604+00	13	Natalie Pancer	1	[{"added": {}}]	34	1
16	2018-11-12 20:35:14.269006+00	14	Evan Strother	1	[{"added": {}}]	34	1
17	2018-11-12 20:36:27.048612+00	15	Sophie Alpert	1	[{"added": {}}]	34	1
18	2018-11-12 20:37:27.299136+00	16	Chaitanya Asawa	1	[{"added": {}}]	34	1
19	2018-11-12 20:37:49.265364+00	17	Cindy Zang Liu	1	[{"added": {}}]	34	1
20	2018-11-12 20:38:14.711001+00	18	Neal Atul Patel	1	[{"added": {}}]	34	1
21	2018-11-12 20:38:42.127843+00	19	Jason Ku Wang	1	[{"added": {}}]	34	1
22	2018-11-12 20:39:58.165252+00	20	John Barbieri	1	[{"added": {}}]	34	1
23	2018-11-12 20:40:31.97944+00	21	Laura Croft	1	[{"added": {}}]	34	1
24	2018-11-12 20:40:56.511162+00	22	Mike Draugelis	1	[{"added": {}}]	34	1
25	2018-11-12 21:12:55.93583+00	23	Eli Cornblath	1	[{"added": {}}]	34	1
26	2018-11-12 21:13:39.862273+00	24	John Glaser	1	[{"added": {}}]	34	1
27	2018-11-12 21:14:16.557502+00	25	Zachary Ives	1	[{"added": {}}]	34	1
28	2018-11-12 21:14:43.232877+00	26	Dan Roth	1	[{"added": {}}]	34	1
29	2018-11-12 21:16:05.787889+00	27	Zachary Hay	1	[{"added": {}}]	34	1
30	2018-11-12 21:17:11.623133+00	28	Rose Schlenk	1	[{"added": {}}]	34	1
31	2018-11-12 21:18:29.456177+00	29	Agi Kajanaku	1	[{"added": {}}]	34	1
32	2018-11-12 21:19:44.530292+00	30	Regina Lee	1	[{"added": {}}]	34	1
33	2018-11-12 21:20:37.271602+00	10	Eli Cornblath	3		34	1
34	2018-11-12 21:41:34.42566+00	1	Updates object (1)	1	[{"added": {}}]	36	1
35	2018-11-12 21:42:01.507469+00	2	Updates object (2)	1	[{"added": {}}]	36	1
36	2018-11-12 21:42:34.281754+00	3	Updates object (3)	1	[{"added": {}}]	36	1
37	2018-11-12 21:43:02.928826+00	4	Updates object (4)	1	[{"added": {}}]	36	1
38	2018-11-12 21:44:02.914743+00	5	Updates object (5)	1	[{"added": {}}]	36	1
39	2018-11-12 21:44:27.10836+00	6	Updates object (6)	1	[{"added": {}}]	36	1
40	2018-11-12 21:44:47.065543+00	7	Updates object (7)	1	[{"added": {}}]	36	1
41	2018-11-12 21:45:43.00326+00	8	Updates object (8)	1	[{"added": {}}]	36	1
42	2018-11-12 21:46:27.647608+00	9	Updates object (9)	1	[{"added": {}}]	36	1
43	2018-11-12 21:47:54.684849+00	10	Updates object (10)	1	[{"added": {}}]	36	1
44	2018-11-12 21:48:22.788865+00	11	Updates object (11)	1	[{"added": {}}]	36	1
45	2018-11-12 21:49:51.487236+00	12	Updates object (12)	1	[{"added": {}}]	36	1
46	2018-11-12 21:50:22.419081+00	13	Updates object (13)	1	[{"added": {}}]	36	1
47	2018-11-12 21:50:41.616752+00	14	Updates object (14)	1	[{"added": {}}]	36	1
48	2018-11-12 21:51:16.14419+00	15	Updates object (15)	1	[{"added": {}}]	36	1
49	2018-11-12 21:51:43.156014+00	16	Updates object (16)	1	[{"added": {}}]	36	1
50	2018-11-12 21:52:02.166574+00	17	Updates object (17)	1	[{"added": {}}]	36	1
51	2018-11-12 21:52:25.413764+00	18	Updates object (18)	1	[{"added": {}}]	36	1
52	2018-11-12 21:52:50.268358+00	19	Updates object (19)	1	[{"added": {}}]	36	1
53	2018-11-12 22:06:07.655769+00	20	Updates object (20)	1	[{"added": {}}]	36	1
54	2018-11-12 22:06:48.15589+00	21	Updates object (21)	1	[{"added": {}}]	36	1
55	2018-11-12 22:07:21.799003+00	22	Updates object (22)	1	[{"added": {}}]	36	1
56	2018-11-12 22:07:52.606566+00	23	Updates object (23)	1	[{"added": {}}]	36	1
57	2018-11-12 22:08:16.036182+00	24	Updates object (24)	1	[{"added": {}}]	36	1
58	2018-11-12 22:08:49.669159+00	25	Updates object (25)	1	[{"added": {}}]	36	1
59	2018-11-12 22:09:18.903427+00	26	Updates object (26)	1	[{"added": {}}]	36	1
60	2018-11-12 22:10:04.528607+00	27	Updates object (27)	1	[{"added": {}}]	36	1
61	2018-11-12 22:10:35.304036+00	28	Updates object (28)	1	[{"added": {}}]	36	1
62	2018-11-12 22:11:07.17705+00	29	Updates object (29)	1	[{"added": {}}]	36	1
63	2018-11-12 22:11:55.34914+00	30	Updates object (30)	1	[{"added": {}}]	36	1
64	2018-11-12 22:12:23.688913+00	31	Updates object (31)	1	[{"added": {}}]	36	1
65	2018-11-12 22:12:54.594474+00	32	Updates object (32)	1	[{"added": {}}]	36	1
66	2018-11-12 22:13:21.979504+00	33	Updates object (33)	1	[{"added": {}}]	36	1
67	2018-11-12 22:13:56.374097+00	34	Updates object (34)	1	[{"added": {}}]	36	1
68	2018-11-12 22:14:21.432692+00	35	Updates object (35)	1	[{"added": {}}]	36	1
69	2018-11-12 22:14:50.018075+00	36	Updates object (36)	1	[{"added": {}}]	36	1
70	2018-11-12 22:15:36.15262+00	37	Updates object (37)	1	[{"added": {}}]	36	1
71	2018-11-12 22:16:09.350427+00	38	Updates object (38)	1	[{"added": {}}]	36	1
72	2018-11-12 22:16:38.301476+00	39	Updates object (39)	1	[{"added": {}}]	36	1
73	2018-11-12 22:17:13.308668+00	40	Updates object (40)	1	[{"added": {}}]	36	1
74	2018-11-12 22:17:41.138956+00	41	Updates object (41)	1	[{"added": {}}]	36	1
75	2018-11-12 22:18:08.879235+00	42	Updates object (42)	1	[{"added": {}}]	36	1
76	2018-11-12 22:18:35.213604+00	43	Updates object (43)	1	[{"added": {}}]	36	1
77	2018-11-12 22:19:21.351274+00	44	Updates object (44)	1	[{"added": {}}]	36	1
78	2018-11-12 22:19:49.583634+00	45	Updates object (45)	1	[{"added": {}}]	36	1
79	2018-11-12 22:20:15.176766+00	46	Updates object (46)	1	[{"added": {}}]	36	1
80	2018-11-12 22:20:47.328067+00	47	Updates object (47)	1	[{"added": {}}]	36	1
81	2018-11-12 22:21:17.001765+00	48	Updates object (48)	1	[{"added": {}}]	36	1
82	2018-11-12 22:21:49.695591+00	49	Updates object (49)	1	[{"added": {}}]	36	1
83	2018-11-12 22:22:17.53905+00	50	Updates object (50)	1	[{"added": {}}]	36	1
84	2018-11-12 22:22:44.913218+00	51	Updates object (51)	1	[{"added": {}}]	36	1
85	2018-11-12 22:23:15.313171+00	52	Updates object (52)	1	[{"added": {}}]	36	1
86	2018-11-12 22:23:53.646048+00	53	Updates object (53)	1	[{"added": {}}]	36	1
87	2018-11-12 22:24:20.120054+00	54	Updates object (54)	1	[{"added": {}}]	36	1
88	2018-11-12 22:24:51.628452+00	55	Updates object (55)	1	[{"added": {}}]	36	1
89	2018-11-12 22:25:24.835281+00	1	Updates object (1)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
90	2018-11-12 22:25:33.204136+00	2	Updates object (2)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
91	2018-11-12 22:25:45.178979+00	3	Updates object (3)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
92	2018-11-12 22:25:57.017145+00	4	Updates object (4)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
93	2018-11-12 22:26:09.367772+00	5	Updates object (5)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
94	2018-11-12 22:26:20.543641+00	6	Updates object (6)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
95	2018-11-12 22:26:29.566907+00	7	Updates object (7)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
96	2018-11-12 22:26:41.179822+00	8	Updates object (8)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
97	2018-11-12 22:27:02.275011+00	9	Updates object (9)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
98	2018-11-12 22:27:15.873779+00	10	Updates object (10)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
99	2018-11-12 22:27:26.961685+00	11	Updates object (11)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
100	2018-11-12 22:27:39.555478+00	12	Updates object (12)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
101	2018-11-12 22:27:48.067925+00	10	Updates object (10)	2	[]	36	1
102	2018-11-12 22:27:52.766422+00	11	Updates object (11)	2	[]	36	1
103	2018-11-12 22:28:03.775527+00	12	Updates object (12)	2	[]	36	1
104	2018-11-12 22:28:14.406097+00	13	Updates object (13)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
105	2018-11-12 22:28:31.853563+00	14	Updates object (14)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
106	2018-11-12 22:28:43.580728+00	14	Updates object (14)	2	[]	36	1
107	2018-11-12 22:28:55.155172+00	15	Updates object (15)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
108	2018-11-12 22:29:10.459564+00	16	Updates object (16)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
109	2018-11-12 22:29:23.699146+00	17	Updates object (17)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
110	2018-11-12 22:29:34.235822+00	18	Updates object (18)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
111	2018-11-12 22:29:46.2481+00	19	Updates object (19)	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
112	2018-11-28 02:11:30.38672+00	30	Regina Lee	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
113	2018-11-28 02:11:42.345513+00	1	Anjali Maheshwari	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
114	2018-11-28 02:11:53.76689+00	2	Danielle Kellier	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
115	2018-11-28 02:12:45.489229+00	3	H. Christy Hong	2	[{"changed": {"fields": ["team_department"]}}]	34	1
116	2018-11-28 02:12:55.420702+00	4	Lucy Yin	2	[{"changed": {"fields": ["team_department"]}}]	34	1
117	2018-11-28 02:13:42.495905+00	5	Radhika Gupta	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
118	2018-11-28 02:13:52.307377+00	6	Elston He	2	[{"changed": {"fields": ["team_department"]}}]	34	1
119	2018-11-28 02:14:04.365411+00	7	Dan Kim	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
120	2018-11-28 02:14:16.703403+00	8	Hongyi Yan	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
121	2018-11-28 02:14:30.151139+00	9	Ahmed Aly	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
122	2018-11-28 02:22:19.170294+00	31	Antonio Hernandez	1	[{"added": {}}]	34	1
123	2018-11-28 02:31:12.805102+00	1	Company object (1)	1	[{"added": {}}]	67	1
124	2018-11-28 02:33:26.058988+00	1	Fast Banana, Tipper Typer	1	[{"added": {}}]	35	1
125	2018-11-28 02:33:51.661714+00	2	Fast Banana, Doodler	1	[{"added": {}}]	35	1
126	2018-11-28 04:17:55.26245+00	23	Eli Cornblath	2	[{"changed": {"fields": ["headshot"]}}]	34	1
127	2018-11-28 04:22:07.205219+00	27	Zachary Hay	2	[{"changed": {"fields": ["team_role", "team_department", "headshot"]}}]	34	1
128	2018-11-28 04:25:16.771486+00	29	Agi Kajanaku	2	[{"changed": {"fields": ["team_department", "headshot"]}}]	34	1
129	2018-11-28 04:29:09.490049+00	1	Anjali Maheshwari	2	[{"changed": {"fields": ["headshot"]}}]	34	1
130	2018-11-28 04:30:42.893716+00	23	Eli Cornblath	2	[{"changed": {"fields": ["team_department", "headshot"]}}]	34	1
131	2018-11-28 04:31:15.158599+00	23	Eli Cornblath	2	[{"changed": {"fields": ["headshot"]}}]	34	1
132	2018-11-28 04:41:25.089386+00	28	Rose Schlenk	2	[{"changed": {"fields": ["team_role", "team_department", "headshot"]}}]	34	1
133	2018-11-28 04:42:09.999136+00	11	Vishnu Rachakonda	2	[{"changed": {"fields": ["team_department"]}}]	34	1
134	2018-11-28 04:42:33.891889+00	12	So Yoshida	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
135	2018-11-28 04:42:48.112565+00	13	Natalie Pancer	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
136	2018-11-28 04:43:01.412073+00	14	Evan Strother	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
137	2018-11-28 04:43:14.268617+00	15	Sophie Alpert	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
138	2018-11-28 04:43:28.636119+00	16	Chaitanya Asawa	2	[{"changed": {"fields": ["team_department"]}}]	34	1
139	2018-11-28 04:43:39.794113+00	17	Cindy Zang Liu	2	[{"changed": {"fields": ["team_department"]}}]	34	1
140	2018-11-28 04:43:51.433269+00	18	Neal Atul Patel	2	[{"changed": {"fields": ["team_department"]}}]	34	1
141	2018-11-28 04:44:05.15547+00	19	Jason Ku Wang	2	[{"changed": {"fields": ["team_department"]}}]	34	1
142	2018-11-28 04:44:15.443775+00	20	John Barbieri	2	[{"changed": {"fields": ["team_department"]}}]	34	1
143	2018-11-28 04:44:24.548277+00	21	Laura Croft	2	[{"changed": {"fields": ["team_department"]}}]	34	1
144	2018-11-28 04:44:38.987755+00	22	Mike Draugelis	2	[{"changed": {"fields": ["team_department"]}}]	34	1
145	2018-11-28 04:44:49.480521+00	24	John Glaser	2	[{"changed": {"fields": ["team_department"]}}]	34	1
146	2018-11-28 04:44:59.604069+00	25	Zachary Ives	2	[{"changed": {"fields": ["team_department"]}}]	34	1
147	2018-11-28 04:46:46.462503+00	26	Dan Roth	2	[{"changed": {"fields": ["team_department"]}}]	34	1
148	2018-11-28 04:49:43.070891+00	32	Jason H. Moore	1	[{"added": {}}]	34	1
149	2018-11-28 05:16:29.174117+00	30	Regina Lee	2	[{"changed": {"fields": ["headshot"]}}]	34	1
150	2018-11-28 05:39:51.14897+00	29	Agi Kajanaku	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
151	2018-11-28 05:40:21.341189+00	11	Vishnu Rachakonda	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
152	2018-11-28 05:40:57.641571+00	23	Eli Cornblath	2	[{"changed": {"fields": ["team_role", "team_department"]}}]	34	1
153	2018-12-21 07:05:45.233254+00	1	Updates object (1)	2	[{"changed": {"fields": ["image"]}}]	36	1
154	2018-12-21 07:06:27.548498+00	2	Updates object (2)	2	[{"changed": {"fields": ["image"]}}]	36	1
155	2018-12-21 07:22:09.438389+00	13	2018-09-23: Robotic Surgeons? Au	2	[{"changed": {"fields": ["publication_date"]}}]	36	1
156	2018-12-21 10:54:47.740284+00	2	Bacchus	1	[{"added": {}}]	67	1
157	2018-12-21 10:56:13.464575+00	3	Bacchus, Doodler	1	[{"added": {}}]	35	1
158	2018-12-21 10:56:36.196073+00	4	Bacchus, Tipper Typer	1	[{"added": {}}]	35	1
159	2018-12-24 07:25:12.615377+00	1	Seminar object (1)	1	[{"added": {}}]	68	1
160	2018-12-24 07:25:52.398286+00	2	Seminar object (2)	1	[{"added": {}}]	68	1
161	2018-12-24 07:26:35.158761+00	3	Seminar object (3)	1	[{"added": {}}]	68	1
162	2018-12-24 07:27:15.074698+00	4	Seminar object (4)	1	[{"added": {}}]	68	1
163	2018-12-24 07:27:45.761994+00	5	Seminar object (5)	1	[{"added": {}}]	68	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	users	user
34	common	aboutmembers
35	common	career
36	common	updates
67	common	company
68	common	seminar
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-11-03 17:28:29.949522+00
2	contenttypes	0002_remove_content_type_name	2018-11-03 17:28:29.960472+00
3	auth	0001_initial	2018-11-03 17:28:30.002652+00
4	auth	0002_alter_permission_name_max_length	2018-11-03 17:28:30.010398+00
5	auth	0003_alter_user_email_max_length	2018-11-03 17:28:30.018309+00
6	auth	0004_alter_user_username_opts	2018-11-03 17:28:30.025945+00
7	auth	0005_alter_user_last_login_null	2018-11-03 17:28:30.033249+00
8	auth	0006_require_contenttypes_0002	2018-11-03 17:28:30.03604+00
9	auth	0007_alter_validators_add_error_messages	2018-11-03 17:28:30.044001+00
10	auth	0008_alter_user_username_max_length	2018-11-03 17:28:30.051656+00
11	users	0001_initial	2018-11-03 17:28:30.094641+00
12	account	0001_initial	2018-11-03 17:28:30.134897+00
13	account	0002_email_max_length	2018-11-03 17:28:30.147101+00
14	admin	0001_initial	2018-11-03 17:28:30.170367+00
15	admin	0002_logentry_remove_auto_add	2018-11-03 17:28:30.187805+00
16	auth	0009_alter_user_last_name_max_length	2018-11-03 17:28:30.204143+00
17	sessions	0001_initial	2018-11-03 17:28:30.217514+00
18	sites	0001_initial	2018-11-03 17:28:30.22615+00
19	sites	0002_alter_domain_unique	2018-11-03 17:28:30.235308+00
20	sites	0003_set_site_domain_and_name	2018-11-03 17:28:30.254366+00
21	socialaccount	0001_initial	2018-11-03 17:28:30.35886+00
22	socialaccount	0002_token_max_lengths	2018-11-03 17:28:30.386461+00
23	socialaccount	0003_extra_data_default_dict	2018-11-03 17:28:30.397446+00
34	common	0001_initial	2018-11-03 19:01:08.012345+00
67	common	0002_auto_20181112_2111	2018-11-12 21:11:40.153519+00
68	common	0003_auto_20181112_2124	2018-11-12 21:24:29.229632+00
69	common	0004_auto_20181112_2139	2018-11-12 21:39:09.220591+00
102	common	0005_auto_20181112_2140	2018-11-12 21:40:22.148308+00
103	common	0006_updates_publication_date	2018-11-12 22:04:26.623546+00
104	common	0007_auto_20181128_0151	2018-11-28 01:51:49.953945+00
105	common	0008_career_company	2018-11-28 01:59:07.945873+00
106	common	0009_aboutmembers_team_department	2018-11-28 02:10:22.904517+00
107	common	0010_auto_20181128_0212	2018-11-28 02:12:35.662608+00
108	common	0011_auto_20181224_0558	2018-12-24 06:44:03.905914+00
109	common	0012_auto_20181224_0643	2018-12-24 06:44:03.940558+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
indq7xc4iozh6txr7304qyphmc3i7k8f	NWFjYzUyYjljNTQ2MzRmMjFiZWFlNTZlZWZkMDY3NzRmZDRkMjM3MTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxYmE0NzlmYTIxOTcwNTY4N2E2OWI5Y2IwMDAxNzAxYTliMWEzZTk1IiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-11-24 19:27:32.057042+00
7d7ynws3yxd5hn9lcet9j9mu2lnvagse	NWFjYzUyYjljNTQ2MzRmMjFiZWFlNTZlZWZkMDY3NzRmZDRkMjM3MTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxYmE0NzlmYTIxOTcwNTY4N2E2OWI5Y2IwMDAxNzAxYTliMWEzZTk1IiwiX3Nlc3Npb25fZXhwaXJ5IjowfQ==	2018-12-12 01:47:12.868152+00
ish29l0n573664xgmellqvqqdalxokfm	ZmQzZWJlMGM5MmMwOGY3NTMxYmExYjg3Y2MzOTZmNDVjMDRhYzIxYjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIxYmE0NzlmYTIxOTcwNTY4N2E2OWI5Y2IwMDAxNzAxYTliMWEzZTk1In0=	2019-01-04 07:00:55.064809+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.django_site (id, domain, name) FROM stdin;
1	healthainetwork.org	hain_site
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$RmdSWWsyMnZnZDRY$E4sZ5vP0HPTWtyU2wspb8A	2018-12-21 07:00:55.027067+00	t	healthainetwork			healthainetwork@gmail.com	t	t	2018-11-03 19:25:36.561638+00	
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 105, true);


--
-- Name: common_aboutmembers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.common_aboutmembers_id_seq', 32, true);


--
-- Name: common_career_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.common_career_id_seq', 4, true);


--
-- Name: common_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.common_company_id_seq', 2, true);


--
-- Name: common_seminar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.common_seminar_id_seq', 5, true);


--
-- Name: common_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.common_updates_id_seq', 55, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 163, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 68, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 109, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: common_aboutmembers common_aboutmembers_name_8d62ca85_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_aboutmembers
    ADD CONSTRAINT common_aboutmembers_name_8d62ca85_uniq UNIQUE (name);


--
-- Name: common_aboutmembers common_aboutmembers_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_aboutmembers
    ADD CONSTRAINT common_aboutmembers_pkey PRIMARY KEY (id);


--
-- Name: common_career common_career_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_career
    ADD CONSTRAINT common_career_pkey PRIMARY KEY (id);


--
-- Name: common_company common_company_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_company
    ADD CONSTRAINT common_company_pkey PRIMARY KEY (id);


--
-- Name: common_seminar common_seminar_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_seminar
    ADD CONSTRAINT common_seminar_pkey PRIMARY KEY (id);


--
-- Name: common_updates common_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_updates
    ADD CONSTRAINT common_updates_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: common_aboutmembers_name_8d62ca85_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX common_aboutmembers_name_8d62ca85_like ON public.common_aboutmembers USING btree (name varchar_pattern_ops);


--
-- Name: common_career_company_id_c89c914d; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX common_career_company_id_c89c914d ON public.common_career USING btree (company_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: common_career common_career_company_id_c89c914d_fk_common_company_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.common_career
    ADD CONSTRAINT common_career_company_id_c89c914d_fk_common_company_id FOREIGN KEY (company_id) REFERENCES public.common_company(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: VBrywLkKCvtKWHFBQepbuupZKSSEXOEQ
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

